import java.util.Scanner;

public class AFD {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Ingrese una cadena (alfabeto {a,b,c}): ");
        String input = sc.nextLine();

        if (acepta(input)) {
            System.out.println("ACEPTADA");
        } else {
            System.out.println("RECHAZADA");
        }

        sc.close();
    }

    public static boolean acepta(String cadena) {
        int estado = 0; 

        for (char simbolo : cadena.toCharArray()) {
            switch (estado) {
                case 0:
                    if (simbolo == 'a') estado = 0;
                    else if (simbolo == 'b') estado = 1;
                    else if (simbolo == 'c') estado = 2;
                    else return false;
                    break;
                case 1:
                    if (simbolo == 'b') estado = 1;
                    else if (simbolo == 'c') estado = 2;
                    else return false;
                    break;
                case 2:
                    if (simbolo == 'c') estado = 2;
                    else return false;
                    break;
            }
        }

        return true;
    }
}
