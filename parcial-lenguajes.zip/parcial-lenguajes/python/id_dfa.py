# id_dfa.py
# AFD para la expresión regular [A-Za-z][A-Za-z0-9]*

def dfa_identifier(s: str) -> bool:
    if not s:
        return False  # no acepta vacío
    # Estado inicial: primer caracter debe ser letra
    if not s[0].isalpha():
        return False
    # Estado de aceptación: resto pueden ser letras o dígitos
    for ch in s[1:]:
        if not (ch.isalpha() or ch.isdigit()):
            return False
    return True


if __name__ == "__main__":
    pruebas = ["x", "var1", "ABC", "id12345", "z9",     # ACEPTA
               "1abc", "_var", "abc!", "", "ñ"]        # RECHAZA
    for t in pruebas:
        print(f"{t!r:10} -> {dfa_identifier(t)}")

