# abc_dfa.py
# AFD para la expresión regular a*b*c*

def dfa_abc(s: str) -> bool:
    state = 0
    for ch in s:
        if state == 0:  # estamos leyendo a's
            if ch == 'a':
                state = 0
            elif ch == 'b':
                state = 1
            elif ch == 'c':
                state = 2
            else:
                return False
        elif state == 1:  # estamos leyendo b's
            if ch == 'b':
                state = 1
            elif ch == 'c':
                state = 2
            else:
                return False
        elif state == 2:  # estamos leyendo c's
            if ch == 'c':
                state = 2
            else:
                return False
    return True  # si terminó en cualquier estado válido

# Pruebas
if __name__ == "__main__":
    tests = ["", "a", "b", "c", "aaabbbccc", "aaacc", "bbbccc", "aaabbb",
             "cab", "abca", "acb", "abcabc"]
    for t in tests:
        print(f"{t!r:10} -> {dfa_abc(t)}")

