// Generated from Maclaurin.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link MaclaurinParser}.
 */
public interface MaclaurinListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link MaclaurinParser#prog}.
	 * @param ctx the parse tree
	 */
	void enterProg(MaclaurinParser.ProgContext ctx);
	/**
	 * Exit a parse tree produced by {@link MaclaurinParser#prog}.
	 * @param ctx the parse tree
	 */
	void exitProg(MaclaurinParser.ProgContext ctx);
}