import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;
import java.io.*;

public class Main {
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String line = br.readLine();  // ejemplo: ex(x=2.5, n=8)
        if (line == null || line.trim().isEmpty()) {
            System.err.println("No hay entrada. Ejemplo: ex(x=1, n=10)");
            System.exit(1);
        }
        CharStream input = CharStreams.fromString(line);
        MaclaurinLexer lexer = new MaclaurinLexer(input);
        CommonTokenStream tokens = new CommonTokenStream(lexer);
        MaclaurinParser parser = new MaclaurinParser(tokens);

        // Parsear
        MaclaurinParser.ProgContext tree = parser.prog();
        Eval eval = new Eval();
        double result = eval.visit(tree);

        System.out.printf("Aproximacion: %.10f%n", result);
    }
}

