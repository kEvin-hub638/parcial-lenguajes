public class Eval extends MaclaurinBaseVisitor<Double> {
    @Override
    public Double visitProg(MaclaurinParser.ProgContext ctx) {
        // Asegurar que hay dos NUM: el primero es x, el segundo es n
        if (ctx.NUM().size() < 2) {
            throw new IllegalArgumentException("Entrada inválida: se requieren x y n");
        }
        double x = Double.parseDouble(ctx.NUM(0).getText());
        int n = Integer.parseInt(ctx.NUM(1).getText());
        if (n < 0) throw new IllegalArgumentException("n debe ser >= 0");
        return maclaurin(x, n);
    }

    private double maclaurin(double x, int n) {
        double sum = 0.0;
        double term = 1.0; // término k=0
        for (int k = 0; k < n; k++) {
            if (k == 0) term = 1.0;
            else term *= x / k;
            sum += term;
        }
        return sum;
    }
}


