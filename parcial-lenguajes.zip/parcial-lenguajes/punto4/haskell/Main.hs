{-# LANGUAGE BangPatterns #-}
import System.Environment (getArgs)
import System.CPUTime (getCPUTime)
import Text.Printf (printf)

gcd' :: Integer -> Integer -> Integer
gcd' a 0 = abs a
gcd' a b = gcd' b (a `mod` b)

loop :: Integer -> Integer -> Integer -> Integer -> Integer
loop 0 _ _ !acc = acc
loop n a b !_   = let r = gcd' a b in r `seq` loop (n-1) a b r

main :: IO ()
main = do
  args <- getArgs
  if length args < 2
    then putStrLn "Uso: mcd-hs a b [reps]"
    else do
      let a    = read (args !! 0) :: Integer
          b    = read (args !! 1) :: Integer
          reps = if length args >= 3 then read (args !! 2) else (1 :: Integer)
      t1 <- getCPUTime
      let !res = loop reps a b 0
      t2 <- getCPUTime
      let elapsed = fromIntegral (t2 - t1) / 1e12 :: Double
      putStrLn $ "MCD(" ++ show a ++ "," ++ show b ++ ") = " ++ show res
      printf   "Tiempo: %.6f s (%d repeticiones)\n" elapsed (fromIntegral reps :: Int)
