#!/usr/bin/env bash
set -e
cd ~/parcial-lenguajes/punto4
echo "a,b,reps,time_c,time_hs" > resultados.csv
for reps in 1 1000 100000; do
  for a in 1071 3918848 1234567891011; do
    for b in 462 1653264 1111111111; do
      tc=$( (/usr/bin/time -f "%e" ./c/mcd-c  $a $b $reps >/dev/null) 2>&1 )
      th=$( (/usr/bin/time -f "%e" ./haskell/mcd-hs $a $b $reps >/dev/null) 2>&1 )
      echo "$a,$b,$reps,$tc,$th" >> resultados.csv
    done
  done
done
echo "Resultados guardados en resultados.csv"

