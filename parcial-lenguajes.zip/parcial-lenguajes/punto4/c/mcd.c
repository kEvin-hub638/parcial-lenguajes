#include <stdio.h>
#include <stdlib.h>
#include <time.h>

static inline long long mcd(long long a, long long b) {
    return (b == 0) ? (a >= 0 ? a : -a) : mcd(b, a % b);
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        fprintf(stderr, "Uso: %s a b [reps]\n", argv[0]);
        return 1;
    }
    long long a = atoll(argv[1]);
    long long b = atoll(argv[2]);
    long long reps = (argc >= 4) ? atoll(argv[3]) : 1;

    struct timespec t1, t2;
    clock_gettime(CLOCK_MONOTONIC, &t1);

    long long r = 0;
    for (long long i = 0; i < reps; i++) r = mcd(a, b);

    clock_gettime(CLOCK_MONOTONIC, &t2);
    double elapsed = (t2.tv_sec - t1.tv_sec) + (t2.tv_nsec - t1.tv_nsec)/1e9;

    printf("MCD(%lld,%lld) = %lld\n", a, b, r);
    printf("Tiempo: %.6f s (%lld repeticiones)\n", elapsed, reps);
    return 0;
}
